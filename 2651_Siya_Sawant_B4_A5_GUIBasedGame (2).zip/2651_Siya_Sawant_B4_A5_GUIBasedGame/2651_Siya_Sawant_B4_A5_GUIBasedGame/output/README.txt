This folder contains a representative GUI preview. Run GameLauncher.java on a desktop with Java installed and capture actual gameplay screenshots for final submission.
