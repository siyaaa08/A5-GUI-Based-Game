public class HumanPlayer extends Player {
 public HumanPlayer(String name, Mark mark) { super(name, mark); }
 @Override public int[] chooseMove(GameBoard board) { return new int[]{-1,-1}; }
}
