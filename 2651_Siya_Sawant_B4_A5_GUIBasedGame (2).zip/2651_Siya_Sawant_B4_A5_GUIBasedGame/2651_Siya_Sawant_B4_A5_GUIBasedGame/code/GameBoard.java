public class GameBoard {
 private final Mark[][] cells = new Mark[3][3];
 public GameBoard() { reset(); }
 public void reset() { for(int r=0;r<3;r++) for(int c=0;c<3;c++) cells[r][c]=Mark.EMPTY; }
 public Mark getCell(int r,int c) { return cells[r][c]; }
 public boolean placeMark(int r,int c,Mark m) { if(r<0||r>2||c<0||c>2||m==Mark.EMPTY||cells[r][c]!=Mark.EMPTY)return false; cells[r][c]=m; return true; }
 public boolean hasWinner(Mark m) {
  for(int i=0;i<3;i++) if((cells[i][0]==m&&cells[i][1]==m&&cells[i][2]==m)||(cells[0][i]==m&&cells[1][i]==m&&cells[2][i]==m)) return true;
  return (cells[0][0]==m&&cells[1][1]==m&&cells[2][2]==m)||(cells[0][2]==m&&cells[1][1]==m&&cells[2][0]==m);
 }
 public boolean isFull() { for(Mark[] row:cells) for(Mark m:row) if(m==Mark.EMPTY)return false; return true; }
}
