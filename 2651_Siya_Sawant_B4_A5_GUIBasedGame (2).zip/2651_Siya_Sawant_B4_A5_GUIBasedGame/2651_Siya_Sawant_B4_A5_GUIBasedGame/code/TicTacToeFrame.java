
import java.awt.*;
import javax.swing.*;

public class TicTacToeFrame extends JFrame {
    private final GameBoard board = new GameBoard();

    private final Player[] players = {
        new HumanPlayer("Player 1", Mark.X),
        new HumanPlayer("Player 2", Mark.O)
    };

    private final JButton[][] buttons = new JButton[3][3];
    private final JLabel status = new JLabel(
        "Player 1 (X), make your move!",
        SwingConstants.CENTER
    );

    private int current = 0;
    private boolean gameOver = false;

    public TicTacToeFrame() {
        super("Tic-Tac-Toe | Java OOP Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(460, 570);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel("TIC-TAC-TOE", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 28));
        title.setForeground(new Color(36, 55, 90));
        title.setBorder(BorderFactory.createEmptyBorder(18, 10, 6, 10));
        add(title, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(3, 3, 8, 8));
        grid.setBorder(BorderFactory.createEmptyBorder(8, 22, 8, 22));
        grid.setBackground(new Color(226, 233, 244));

        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                final int rr = r;
                final int cc = c;

                JButton button = new JButton("");
                button.setFont(new Font("SansSerif", Font.BOLD, 54));
                button.setFocusPainted(false);
                button.setBackground(Color.WHITE);
                button.addActionListener(e -> handleMove(rr, cc));

                buttons[r][c] = button;
                grid.add(button);
            }
        }

        add(grid, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout(8, 8));
        bottom.setBorder(BorderFactory.createEmptyBorder(4, 20, 18, 20));
        status.setFont(new Font("SansSerif", Font.PLAIN, 15));
        bottom.add(status, BorderLayout.CENTER);

        JButton reset = new JButton("New Game");
        reset.addActionListener(e -> resetGame());
        bottom.add(reset, BorderLayout.SOUTH);
        add(bottom, BorderLayout.SOUTH);

        getContentPane().setBackground(new Color(246, 248, 252));
    }

    private void handleMove(int r, int c) {
        if (gameOver ||
            !board.placeMark(r, c, players[current].getMark())) {
            return;
        }

        Mark mark = players[current].getMark();
        buttons[r][c].setText(mark.getSymbol());
        buttons[r][c].setForeground(
            mark == Mark.X
                ? new Color(37, 99, 235)
                : new Color(220, 70, 70)
        );

        if (board.hasWinner(mark)) {
            status.setText(players[current].getName() + " wins!");
            gameOver = true;

            JOptionPane.showMessageDialog(
                this,
                players[current].getName() + " wins!",
                "Game Over",
                JOptionPane.INFORMATION_MESSAGE
            );
        } else if (board.isFull()) {
            status.setText("It's a draw!");
            gameOver = true;

            JOptionPane.showMessageDialog(
                this,
                "It's a draw!",
                "Game Over",
                JOptionPane.INFORMATION_MESSAGE
            );
        } else {
            current = 1 - current;
            status.setText(
                players[current].getName() + " (" +
                players[current].getMark().getSymbol() +
                "), make your move!"
            );
        }
    }

    private void resetGame() {
        board.reset();
        gameOver = false;
        current = 0;

        for (JButton[] row : buttons) {
            for (JButton button : row) {
                button.setText("");
            }
        }

        status.setText("Player 1 (X), make your move!");
    }
}